# MME User Study

User study code and files for the linear regression modelling user study

## Requirements:
Install the following packages (pip3 install <NAME>) before running the study code
- seaborn
- torch
- pandas
- pystan
- arviz